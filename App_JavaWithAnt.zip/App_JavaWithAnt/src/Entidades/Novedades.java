/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Novedades {
    private int id_Novedades;
    private String Producto;
    private String Filtros;

    public Novedades(int id_Novedades, String Producto, String Filtros) {
        this.id_Novedades = id_Novedades;
        this.Producto = Producto;
        this.Filtros = Filtros;
    }

    public int getId_Novedades() {
        return id_Novedades;
    }

    public String getProducto() {
        return Producto;
    }

    public String getFiltros() {
        return Filtros;
    }

    public void setId_Novedades(int id_Novedades) {
        this.id_Novedades = id_Novedades;
    }

    public void setProducto(String Producto) {
        this.Producto = Producto;
    }

    public void setFiltros(String Filtros) {
        this.Filtros = Filtros;
    }
    
    public String mostrardatos() {
        return "Novedades{" + "id_Novedades=" + id_Novedades + ", Producto=" + Producto + ", Filtros=" + Filtros + '}';
    }
    
    
}
