/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Productos {
    private int id_Productos;
    private int Imagen;
    private String Nombre;
    private int Precio;
    private String Marca_fav;
    private int Cant_carrito;
    private String Color;
    private String Etiqueta_NuevoOferta;

    public Productos(int id_Productos, int Imagen, String Nombre, int Precio, String Marca_fav, int Cant_carrito, String Color, String Etiqueta_NuevoOferta) {
        this.id_Productos = id_Productos;
        this.Imagen = Imagen;
        this.Nombre = Nombre;
        this.Precio = Precio;
        this.Marca_fav = Marca_fav;
        this.Cant_carrito = Cant_carrito;
        this.Color = Color;
        this.Etiqueta_NuevoOferta = Etiqueta_NuevoOferta;
    }

    public int getId_Productos() {
        return id_Productos;
    }

    public int getImagen() {
        return Imagen;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getPrecio() {
        return Precio;
    }

    public String getMarca_fav() {
        return Marca_fav;
    }

    public int getCant_carrito() {
        return Cant_carrito;
    }

    public String getColor() {
        return Color;
    }

    public String getEtiqueta_NuevoOferta() {
        return Etiqueta_NuevoOferta;
    }

    public void setId_Productos(int id_Productos) {
        this.id_Productos = id_Productos;
    }

    public void setImagen(int Imagen) {
        this.Imagen = Imagen;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public void setMarca_fav(String Marca_fav) {
        this.Marca_fav = Marca_fav;
    }

    public void setCant_carrito(int Cant_carrito) {
        this.Cant_carrito = Cant_carrito;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setEtiqueta_NuevoOferta(String Etiqueta_NuevoOferta) {
        this.Etiqueta_NuevoOferta = Etiqueta_NuevoOferta;
    }

    public String mostrardatos() {
        return "Productos{" + "id_Productos=" + id_Productos + ", Imagen=" + Imagen + ", Nombre=" + Nombre + ", Precio=" + Precio + ", Marca_fav=" + Marca_fav + ", Cant_carrito=" + Cant_carrito + ", Color=" + Color + ", Etiqueta_NuevoOferta=" + Etiqueta_NuevoOferta + '}';
    }
    
    
}
