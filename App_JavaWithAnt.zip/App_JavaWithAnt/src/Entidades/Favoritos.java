/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Favoritos {
    private int id_Favoritos;
    private String Productos;
    private String Filtros;

    public Favoritos(int id_Favoritos, String Productos, String Filtros) {
        this.id_Favoritos = id_Favoritos;
        this.Productos = Productos;
        this.Filtros = Filtros;
    }

    //getter
    
    public int getId_Favoritos() {
        return id_Favoritos;
    }

    public String getProductos() {
        return Productos;
    }

    public String getFiltros() {
        return Filtros;
    }

    //sett
    
    public void setId_Favoritos(int id_Favoritos) {
        this.id_Favoritos = id_Favoritos;
    }

    public void setProductos(String Productos) {
        this.Productos = Productos;
    }

    public void setFiltros(String Filtros) {
        this.Filtros = Filtros;
    }
    
    public String mostrardatos() {
        return "Favoritos{" + "id_Favoritos=" + id_Favoritos + ", Productos=" + Productos + ", Filtros=" + Filtros + '}';
    }
    
    
}
