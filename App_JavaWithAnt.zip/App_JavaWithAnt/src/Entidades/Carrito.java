/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Carrito {
    private int id_Carrito;
    private int Cant_prod_en_carrito;
    private String Finalizar_compra;
    private String Volver_al_inicio;
    private String Producto;

    public Carrito(int id_Carrito, int Cant_prod_en_carrito, String Finalizar_compra, String Volver_al_inicio, String Producto) {
        this.id_Carrito = id_Carrito;
        this.Cant_prod_en_carrito = Cant_prod_en_carrito;
        this.Finalizar_compra = Finalizar_compra;
        this.Volver_al_inicio = Volver_al_inicio;
        this.Producto = Producto;
    }

    public int getId_Carrito() {
        return id_Carrito;
    }

    public int getCant_prod_en_carrito() {
        return Cant_prod_en_carrito;
    }

    public String getFinalizar_compra() {
        return Finalizar_compra;
    }

    public String getVolver_al_inicio() {
        return Volver_al_inicio;
    }

    public String getProducto() {
        return Producto;
    }

    public void setId_Carrito(int id_Carrito) {
        this.id_Carrito = id_Carrito;
    }

    public void setCant_prod_en_carrito(int Cant_prod_en_carrito) {
        this.Cant_prod_en_carrito = Cant_prod_en_carrito;
    }

    public void setFinalizar_compra(String Finalizar_compra) {
        this.Finalizar_compra = Finalizar_compra;
    }

    public void setVolver_al_inicio(String Volver_al_inicio) {
        this.Volver_al_inicio = Volver_al_inicio;
    }

    public void setProducto(String Producto) {
        this.Producto = Producto;
    }

    public String mostrardatos() {
        return "Carrito{" + "id_Carrito=" + id_Carrito + ", Cant_prod_en_carrito=" + Cant_prod_en_carrito + ", Finalizar_compra=" + Finalizar_compra + ", Volver_al_inicio=" + Volver_al_inicio + ", Producto=" + Producto + '}';
    }
    
    
}
