/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Informacion {
    private int id_Informacion;
    private String Camb_y_devol;
    private String Pol_de_envios;
    private String Enc_satisfaccion;
    private String Guia_de_tallas;

    public Informacion(int id_Informacion, String Camb_y_devol, String Pol_de_envios, String Enc_satisfaccion, String Guia_de_tallas) {
        this.id_Informacion = id_Informacion;
        this.Camb_y_devol = Camb_y_devol;
        this.Pol_de_envios = Pol_de_envios;
        this.Enc_satisfaccion = Enc_satisfaccion;
        this.Guia_de_tallas = Guia_de_tallas;
    }

    public int getId_Informacion() {
        return id_Informacion;
    }

    public String getCamb_y_devol() {
        return Camb_y_devol;
    }

    public String getPol_de_envios() {
        return Pol_de_envios;
    }

    public String getEnc_satisfaccion() {
        return Enc_satisfaccion;
    }

    public String getGuia_de_tallas() {
        return Guia_de_tallas;
    }

    public void setId_Informacion(int id_Informacion) {
        this.id_Informacion = id_Informacion;
    }

    public void setCamb_y_devol(String Camb_y_devol) {
        this.Camb_y_devol = Camb_y_devol;
    }

    public void setPol_de_envios(String Pol_de_envios) {
        this.Pol_de_envios = Pol_de_envios;
    }

    public void setEnc_satisfaccion(String Enc_satisfaccion) {
        this.Enc_satisfaccion = Enc_satisfaccion;
    }

    public void setGuia_de_tallas(String Guia_de_tallas) {
        this.Guia_de_tallas = Guia_de_tallas;
    }
    
    public String mostrardatos() {
        return "Informacion{" + "id_Informacion=" + id_Informacion + ", Camb_y_devol=" + Camb_y_devol + ", Pol_de_envios=" + Pol_de_envios + ", Enc_satisfaccion=" + Enc_satisfaccion + ", Guia_de_tallas=" + Guia_de_tallas + '}';
    }
    
    
}
