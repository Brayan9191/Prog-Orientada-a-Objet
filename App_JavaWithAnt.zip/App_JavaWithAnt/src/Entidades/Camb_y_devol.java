/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Camb_y_devol {
    private int id_Camb_y_devol;
    private String Pol_de_retractos;
    private String Pol_garantias;
    private String Pol_de_cambios;

    public Camb_y_devol(int id_Camb_y_devol, String Pol_de_retractos, String Pol_garantias, String Pol_de_cambios) {
        this.id_Camb_y_devol = id_Camb_y_devol;
        this.Pol_de_retractos = Pol_de_retractos;
        this.Pol_garantias = Pol_garantias;
        this.Pol_de_cambios = Pol_de_cambios;
    }

    //get
    
    public int getId_Camb_y_devol() {
        return id_Camb_y_devol;
    }

    public String getPol_de_retractos() {
        return Pol_de_retractos;
    }

    public String getPol_garantias() {
        return Pol_garantias;
    }

    public String getPol_de_cambios() {
        return Pol_de_cambios;
    }

    //set

    public void setId_Camb_y_devol(int id_Camb_y_devol) {
        this.id_Camb_y_devol = id_Camb_y_devol;
    }

    public void setPol_de_retractos(String Pol_de_retractos) {
        this.Pol_de_retractos = Pol_de_retractos;
    }

    public void setPol_garantias(String Pol_garantias) {
        this.Pol_garantias = Pol_garantias;
    }

    public void setPol_de_cambios(String Pol_de_cambios) {
        this.Pol_de_cambios = Pol_de_cambios;
    }
    
    
    
    public String mostrardatos() {
        return "Camb_y_devol{" + "id_Camb_y_devol=" + id_Camb_y_devol + ", Pol_de_retractos=" + Pol_de_retractos + ", Pol_garantias=" + Pol_garantias + ", Pol_de_cambios=" + Pol_de_cambios + '}';
    }
    
    
}
