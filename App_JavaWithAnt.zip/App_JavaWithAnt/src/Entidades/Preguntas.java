/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Preguntas {
    private int id_Preguntas;
    private String Cal_del_1_al_10;
    private String Si_o_No;

    public Preguntas(int id_Preguntas, String Cal_del_1_al_10, String Si_o_No) {
        this.id_Preguntas = id_Preguntas;
        this.Cal_del_1_al_10 = Cal_del_1_al_10;
        this.Si_o_No = Si_o_No;
    }

    public int getId_Preguntas() {
        return id_Preguntas;
    }

    public String getCal_del_1_al_10() {
        return Cal_del_1_al_10;
    }

    public String getSi_o_No() {
        return Si_o_No;
    }

    public void setId_Preguntas(int id_Preguntas) {
        this.id_Preguntas = id_Preguntas;
    }

    public void setCal_del_1_al_10(String Cal_del_1_al_10) {
        this.Cal_del_1_al_10 = Cal_del_1_al_10;
    }

    public void setSi_o_No(String Si_o_No) {
        this.Si_o_No = Si_o_No;
    }

    public String mostrardatos() {
        return "Preguntas{" + "id_Preguntas=" + id_Preguntas + ", Cal_del_1_al_10=" + Cal_del_1_al_10 + ", Si_o_No=" + Si_o_No + '}';
    }
    
    
}
